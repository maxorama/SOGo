Please refer to ../README-OSX.txt for compilation directives.

Prebinding Notes (DEPRECATED, for reference only)
=================================================

sope-xml: 0xC0000000 - 0xC0FFFFFF

0xC0000000 SaxObjC
0xC0200000 DOM
0xC0400000 XmlRpc
0xC0FF0000 sope-xml
